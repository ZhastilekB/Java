public class Main {

    public static void printGreeting(String name) {
        System.out.println("Hello, " + name + "!");
    }
    public static void main(String[] args) {
        printGreeting("Miles");
        printGreeting("Piter");
    }
}
