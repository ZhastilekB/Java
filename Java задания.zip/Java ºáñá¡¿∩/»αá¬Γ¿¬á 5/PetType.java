public enum PetType {
    DOG,
    CAT
}
